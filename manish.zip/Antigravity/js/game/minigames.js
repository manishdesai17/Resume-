// 20 Traditional Indian Village Childhood Minigames Engine
class VillageMinigames {
    constructor(playerState) {
        this.playerState = playerState;
        this.gamesList = [
            { id: 'cricket', name: 'Cricket', icon: '🏏', desc: 'Score SIXES with village friends in the green field pitch!', reward: 150 },
            { id: 'football', name: 'Football', icon: '⚽', desc: 'Kick & score goals past the wooden village posts!', reward: 120 },
            { id: 'khokho', name: 'Kho-Kho', icon: '🏃', desc: 'Tag your speed opponents in fast-paced team race!', reward: 100 },
            { id: 'kabaddi', name: 'Kabaddi', icon: '🤼', desc: 'Chant Kabaddi-Kabaddi & raid the opponent defense line!', reward: 140 },
            { id: 'kite', name: 'Kite Flying', icon: '🪁', desc: 'Fly your colorful Patang high & cut opponent strings in sky!', reward: 100 },
            { id: 'volleyball', name: 'Volleyball', icon: '🏐', desc: 'Spike the ball over the net in the dusty village court!', reward: 110 },
            { id: 'running', name: 'Running Race', icon: '🏃', desc: 'Sprint along the 2 KM school dirt road to win first rank!', reward: 130 },
            { id: 'gillidanda', name: 'Gilli-Danda', icon: '🪵', desc: 'Flick the wooden Gilli into the air and strike it far!', reward: 90 },
            { id: 'tugofwar', name: 'Tug of War', icon: '🪢', desc: 'Pull the thick jute rope with your 7 family members & friends!', reward: 150 },
            { id: 'archery', name: 'Archery Target', icon: '🏹', desc: 'Aim wooden bow & arrow at the center target board!', reward: 160 },
            { id: 'stonetarget', name: 'Stone Target', icon: '🥎', desc: 'Throw smooth stones to hit suspended tin cans!', reward: 80 },
            { id: 'bicyclerace', name: 'Bicycle Race', icon: '🚲', desc: 'Race your Hero Bicycle over dirt bumps & wooden bridge!', reward: 200 },
            { id: 'swimming', name: 'River Swimming', icon: '🏊', desc: 'Dive into the clear blue village river & swim across!', reward: 110 },
            { id: 'bullockrace', name: 'Bullock Cart Race', icon: '🐂', desc: 'Drive decorated bullock cart across muddy village tracks!', reward: 250 },
            { id: 'treeclimbing', name: 'Tree Climbing', icon: '🌳', desc: 'Climb high Banyan & Mango trees to gather fresh fruit!', reward: 100 },
            { id: 'slingshot', name: 'Slingshot Target', icon: '🏹', desc: 'Aim rubber Gulel slingshot at high coconut targets!', reward: 120 },
            { id: 'coconut', name: 'Coconut Throwing', icon: '🥥', desc: 'Throw heavy coconuts to crack them open for fresh water!', reward: 90 },
            { id: 'lagori', name: 'Lagori (Seven Stones)', icon: '🪨', desc: 'Break the 7 stacked flat stones & rebuild before getting hit!', reward: 180 },
            { id: 'marbles', name: 'Marbles (Kanchi)', icon: '🔴', desc: 'Aim your shiny glass marble to knock out opponent marbles!', reward: 130 },
            { id: 'hideandseek', name: 'Hide and Seek', icon: '🏃', desc: 'Hide behind 20 village homes & Banyan tree roots!', reward: 100 }
        ];
    }

    playMinigame(gameId) {
        const game = this.gamesList.find(g => g.id === gameId);
        if (!game) return null;

        // Reward player with Money & Energy reduction
        this.playerState.money += game.reward;
        this.playerState.hunger = Math.max(0, this.playerState.hunger - 10);
        this.playerState.water = Math.max(0, this.playerState.water - 15);

        audio.playPowerup();

        return {
            title: game.name,
            message: `🎉 You played ${game.name}! You won ₹${game.reward} rupees! (+₹${game.reward} Money)`
        };
    }
}
