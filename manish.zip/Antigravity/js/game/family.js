// 7-Member Family & Meal Gathering Manager
class FamilySystem {
    constructor(playerState) {
        this.playerState = playerState;
        this.members = [
            { name: "Grandfather (Dada)", relation: "Grandfather", advice: "Greetings son! Work hard in farm and studies." },
            { name: "Grandmother (Dadi)", relation: "Grandmother", advice: "Have fresh milk and ghee daily for strong health!" },
            { name: "Father (Bapu)", relation: "Father", advice: "Ride carefully to school. Take the Hero Bicycle!" },
            { name: "Mother (Mataji)", relation: "Mother", advice: "Lunch is prepared on the dining mat. Sit with family!" },
            { name: "Elder Brother", relation: "Brother", advice: "Let's play Cricket & Lagori with village friends!" },
            { name: "Younger Sister", relation: "Sister", advice: "Take me on your bicycle to the village river!" }
        ];
    }

    eatFamilyMeal() {
        this.playerState.eat(50);
        this.playerState.drinkWater(40);
        this.playerState.health = Math.min(100, this.playerState.health + 25);
        return "You sat with your 7 family members on the traditional mat and enjoyed fresh Roti, Sabzi & Pure Milk! (+50 Hunger, +40 Water, +25 Health)";
    }
}
