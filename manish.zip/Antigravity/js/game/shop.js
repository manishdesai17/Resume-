// Vehicle & Item Shop Manager
class VillageShop {
    constructor(playerState) {
        this.playerState = playerState;
        this.items = {
            bicycle: { name: 'Hero Bicycle', price: 1500, icon: '🚲' },
            phone: { name: 'Smartphone 5G', price: 5000, icon: '📱' },
            motorbike: { name: 'Bullet Motorbike', price: 45000, icon: '🏍️' },
            car: { name: 'Village SUV Car', price: 250000, icon: '🚗' }
        };
    }

    buyItem(itemId) {
        const item = this.items[itemId];
        if (!item) return { success: false, message: 'Invalid item!' };

        if (this.playerState.inventory[itemId]) {
            return { success: false, message: `You already own the ${item.name}!` };
        }

        if (this.playerState.money < item.price) {
            return { success: false, message: `Not enough rupees! You need ₹${item.price}.` };
        }

        this.playerState.money -= item.price;
        this.playerState.inventory[itemId] = true;
        audio.playPowerup();

        return { success: true, message: `Congratulations! You bought ${item.name} ${item.icon}!` };
    }
}
