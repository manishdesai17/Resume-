// Vehicle Riding & Driving Physics Manager
class VehicleManager {
    constructor(playerControls, playerState) {
        this.controls = playerControls;
        this.playerState = playerState;
    }

    mountVehicle(type) {
        if (!this.playerState.inventory[type]) {
            return false;
        }

        this.controls.currentVehicle = type;
        
        if (type === 'bicycle') audio.playBicycleBell();
        else if (type === 'motorbike' || type === 'car') audio.playMotorbikeEngine();

        return true;
    }

    dismount() {
        this.controls.currentVehicle = null;
    }
}
