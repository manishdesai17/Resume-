// Player Stats, Realistic Needs, 10-Day Education Life Cycle, Degree & Cow Milk Business
class PlayerState {
    constructor() {
        // Survival Needs (0 - 100)
        this.health = 100;
        this.hunger = 100;
        this.water = 100;
        this.energy = 100;
        
        // Time & Education Progression
        this.dayCount = 1;
        this.timeOfDay = 8.0; // 8:00 AM (0 to 24 hours)
        this.ageYears = 8;    // Start as 8-year-old child
        this.money = 500;     // Initial rupees

        // Education Milestones
        // Days 1 - 10: School Life
        // Day 10: College Admission
        // Days 11 - 20: College Life (10 Days of College)
        // Day 20: Graduation & Degree Certificate Awarded!
        this.schoolDaysDone = 0;
        this.collegeDaysDone = 0;
        this.hasCollegeAdmission = false;
        this.degreeEarned = false;
        this.degreeName = null;

        // Career & Business
        this.lifeStage = "School Life (Days 1-10)";
        this.careerChoice = null; // 'Job' | 'Farming' | 'Dairy Milk Business'
        this.isMarried = false;

        // Cow Dairy Milk Business
        this.milkCans = 0;
        this.totalMilkSold = 0;

        // Inventory & Equipment
        this.inventory = {
            bicycle: false,
            phone: false,
            motorbike: false,
            car: false
        };
    }

    updateTime(deltaTime) {
        // 1 real second = 4 game minutes
        this.timeOfDay += (deltaTime * 4) / 60;
        
        // Day rollover (24:00)
        if (this.timeOfDay >= 24) {
            this.timeOfDay -= 24;
            this.dayCount++;
            
            // Age growth
            this.ageYears = Math.min(60, 8 + Math.floor(this.dayCount * 0.8));

            // Process Education Schedule based on Day Count
            this.processEducationSchedule();

            // Daily income based on career
            if (this.careerChoice === 'Job' && this.degreeEarned) {
                this.money += 1500; // High salary after Degree
            } else if (this.careerChoice === 'Farming') {
                this.money += 400;  // Farm harvest profit
            } else if (this.careerChoice === 'Dairy Milk Business') {
                this.money += 600;  // Base dairy profit
            } else {
                this.money += 50;   // Pocket money from parents
            }
        }

        // Realistic Survival Needs Depletion (Down system)
        this.water = Math.max(0, this.water - deltaTime * 0.35);
        this.hunger = Math.max(0, this.hunger - deltaTime * 0.25);
        this.energy = Math.max(0, this.energy - deltaTime * 0.15);

        // Health drops if water or hunger reaches 0
        if (this.water <= 0 || this.hunger <= 0) {
            this.health = Math.max(0, this.health - deltaTime * 2.0);
        } else if (this.water > 50 && this.hunger > 50 && this.energy > 50) {
            // Health slowly recovers if well-fed & hydrated (Up system)
            this.health = Math.min(100, this.health + deltaTime * 0.5);
        }

        // Night Dayro ambient music synth at 9 PM (21:00)
        if (Math.floor(this.timeOfDay) === 21 && Math.random() < 0.05) {
            audio.playDayroSynth();
        }
    }

    processEducationSchedule() {
        if (this.dayCount <= 10) {
            // Days 1 to 10: School Life
            this.schoolDaysDone = this.dayCount;
            this.lifeStage = `School Life (Day ${this.schoolDaysDone}/10)`;

            if (this.dayCount === 10 && !this.hasCollegeAdmission) {
                this.hasCollegeAdmission = true;
                setTimeout(() => {
                    alert("🎓 CONGRATULATIONS! You completed 10 Days of School! You got Admission into Village Science & Commerce College!");
                }, 500);
            }
        } else if (this.dayCount > 10 && this.dayCount <= 20) {
            // Days 11 to 20: College Life (10 Days of College)
            this.collegeDaysDone = this.dayCount - 10;
            this.lifeStage = `College Life (Day ${this.collegeDaysDone}/10)`;

            if (this.dayCount === 20 && !this.degreeEarned) {
                this.degreeEarned = true;
                this.degreeName = "Bachelor of Agricultural Science & Business";
                setTimeout(() => {
                    alert("📜 GRAND GRADUATION CEREMONY! You completed 10 Days of College and earned your DEGREE DEGREE: 'Bachelor of Science & Business'! You can now apply for High-Paying Jobs or expand your Dairy Milk Business!");
                }, 500);
            }
        } else {
            // Day 21+: Graduate Adult Life
            this.lifeStage = `Graduate Adult (${this.careerChoice || "Degree Holder"})`;
        }
    }

    milkCow() {
        this.milkCans += 1;
        audio.playCowMoo();
        return `🥛 You milked the cow! Collected 1 Milk Can (Total: ${this.milkCans} Cans). Sell at Village Dairy for ₹200/can!`;
    }

    sellMilk() {
        if (this.milkCans <= 0) {
            return { success: false, message: "No milk cans to sell! Milk the cows first." };
        }
        const earned = this.milkCans * 200;
        this.money += earned;
        this.totalMilkSold += this.milkCans;
        const count = this.milkCans;
        this.milkCans = 0;
        audio.playPowerup();
        return { success: true, message: `🥛 Sold ${count} Milk Cans at Village Dairy! Earned ₹${earned} rupees!` };
    }

    drinkWater(amount = 50) {
        this.water = Math.min(100, this.water + amount);
        this.health = Math.min(100, this.health + 10);
        audio.playWaterSplash();
    }

    eat(amount = 45) {
        this.hunger = Math.min(100, this.hunger + amount);
        this.health = Math.min(100, this.health + 15);
    }

    sleep() {
        this.energy = 100;
        this.health = Math.min(100, this.health + 30);
        this.timeOfDay = 6.0; // Wake up at 6 AM
        this.dayCount++;
        this.processEducationSchedule();
    }
}
