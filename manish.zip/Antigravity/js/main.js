// Main Game Initialization & State Machine
class VillageGame {
    constructor() {
        this.renderer = new VillageRenderer();
        this.terrain = new VillageTerrain(this.renderer.scene);
        this.controls = new PlayerControls(this.renderer.camera, this.renderer.renderer.domElement);
        this.playerState = new PlayerState();
        this.familySystem = new FamilySystem(this.playerState);
        this.vehicleManager = new VehicleManager(this.controls, this.playerState);
        this.minigames = new VillageMinigames(this.playerState);
        this.shop = new VillageShop(this.playerState);

        this.isRunning = false;
        this.lastTime = performance.now();

        this.initUI();
    }

    initUI() {
        // Start Game Button
        document.getElementById('btn-start-game').addEventListener('click', () => {
            this.startGame();
        });

        // Guide Modal
        document.getElementById('btn-controls-guide').addEventListener('click', () => {
            document.getElementById('screen-guide').classList.remove('hidden');
        });
        document.getElementById('btn-close-guide').addEventListener('click', () => {
            document.getElementById('screen-guide').classList.add('hidden');
        });

        // APK Instructions Modal
        document.getElementById('btn-apk-info').addEventListener('click', () => {
            document.getElementById('screen-apk').classList.remove('hidden');
        });
        document.getElementById('btn-close-apk').addEventListener('click', () => {
            document.getElementById('screen-apk').classList.add('hidden');
        });

        // Degree Certificate Modal
        document.getElementById('btn-degree').addEventListener('click', () => {
            if (!this.playerState.degreeEarned) {
                alert(`🎓 DEGREE STATUS: Complete 10 Days of School and 10 Days of College to earn your Graduation Degree Certificate!\n\nCurrent Progress: Day ${this.playerState.dayCount} (${this.playerState.lifeStage})`);
            } else {
                document.getElementById('screen-degree').classList.remove('hidden');
            }
        });
        document.getElementById('btn-close-degree').addEventListener('click', () => {
            document.getElementById('screen-degree').classList.add('hidden');
        });

        // Milk Selling Button
        document.getElementById('btn-sell-milk').addEventListener('click', () => {
            const res = this.playerState.sellMilk();
            alert(res.message);
            this.updateHUD();
        });

        // Mobile Milk Cow Touch Button
        const btnTouchMilk = document.getElementById('btn-touch-milk');
        if (btnTouchMilk) {
            btnTouchMilk.addEventListener('click', () => {
                const msg = this.playerState.milkCow();
                alert(msg);
                this.updateHUD();
            });
        }

        // HUD Quick Action Buttons
        document.getElementById('btn-games').addEventListener('click', () => this.openMinigamesModal());
        document.getElementById('btn-close-games').addEventListener('click', () => {
            document.getElementById('screen-minigames').classList.add('hidden');
        });

        document.getElementById('btn-shop').addEventListener('click', () => this.openShopModal());
        document.getElementById('btn-close-shop').addEventListener('click', () => {
            document.getElementById('screen-shop').classList.add('hidden');
        });

        document.getElementById('btn-family').addEventListener('click', () => {
            document.getElementById('screen-family').classList.remove('hidden');
        });
        document.getElementById('btn-close-family').addEventListener('click', () => {
            document.getElementById('screen-family').classList.add('hidden');
        });

        document.getElementById('btn-eat-family-meal').addEventListener('click', () => {
            const msg = this.familySystem.eatFamilyMeal();
            alert(msg);
            this.updateHUD();
        });

        document.getElementById('btn-phone').addEventListener('click', () => {
            if (!this.playerState.inventory.phone) {
                alert("You need to buy a Smartphone from the Vehicle & Item Shop first! (₹5,000)");
                return;
            }
            document.getElementById('screen-phone').classList.remove('hidden');
        });
        document.getElementById('btn-close-phone').addEventListener('click', () => {
            document.getElementById('screen-phone').classList.add('hidden');
        });

        // Dismount Vehicle button
        document.getElementById('btn-dismount').addEventListener('click', () => {
            this.vehicleManager.dismount();
            document.getElementById('vehicle-hud').classList.add('hidden');
        });

        // Shop Buy Buttons
        document.getElementById('buy-bicycle').addEventListener('click', () => this.handleBuy('bicycle'));
        document.getElementById('buy-phone').addEventListener('click', () => this.handleBuy('phone'));
        document.getElementById('buy-motorbike').addEventListener('click', () => this.handleBuy('motorbike'));
        document.getElementById('buy-car').addEventListener('click', () => this.handleBuy('car'));

        // Smartphone Apps Wiring
        document.getElementById('app-jobs').addEventListener('click', () => {
            if (!this.playerState.degreeEarned) {
                const choice = confirm("You haven't completed 10 Days of College Degree yet!\nClick OK for FARMING 🌾 (₹400/day)\nClick CANCEL for DAIRY MILK BUSINESS 🥛 (₹600/day)");
                this.playerState.careerChoice = choice ? 'Farming' : 'Dairy Milk Business';
            } else {
                const choice = confirm("🎓 DEGREE HOLDER JOB APP:\nClick OK for HIGH-PAYING VILLAGE ENGINEER JOB 💼 (₹1500/day)\nClick CANCEL for EXPANDED DAIRY FARM 🥛");
                this.playerState.careerChoice = choice ? 'Job' : 'Dairy Milk Business';
            }
            document.getElementById('phone-app-content').innerHTML = `<h4>CAREER UPDATED</h4><p>Your career is set to: <strong>${this.playerState.careerChoice}</strong>!</p>`;
        });

        document.getElementById('app-marriage').addEventListener('click', () => {
            if (this.playerState.dayCount < 20) {
                document.getElementById('phone-app-content').innerHTML = `<h4>MARRIAGE MATCH</h4><p>Complete College Degree first! Day Count: ${this.playerState.dayCount}/20</p>`;
            } else {
                this.playerState.isMarried = true;
                document.getElementById('phone-app-content').innerHTML = `<h4>🎉 CONGRATULATIONS!</h4><p>You got married to a wonderful village partner! Enjoy married life with family!</p>`;
            }
        });
    }

    startGame() {
        document.getElementById('screen-main-menu').classList.add('hidden');
        document.getElementById('hud').classList.remove('hidden');
        this.isRunning = true;
        this.animate(performance.now());
    }

    openMinigamesModal() {
        const grid = document.getElementById('minigames-grid');
        grid.innerHTML = '';

        this.minigames.gamesList.forEach(g => {
            const card = document.createElement('div');
            card.className = 'game-card-item';
            card.innerHTML = `
                <div class="icon">${g.icon}</div>
                <h4>${g.name}</h4>
                <p style="font-size: 0.7rem; color: #94a3b8; margin-top: 4px;">${g.desc}</p>
                <button class="btn btn-small" style="margin-top: 8px;">PLAY (+₹${g.reward})</button>
            `;
            card.querySelector('button').addEventListener('click', () => {
                const res = this.minigames.playMinigame(g.id);
                if (res) alert(res.message);
                this.updateHUD();
            });
            grid.appendChild(card);
        });

        document.getElementById('screen-minigames').classList.remove('hidden');
    }

    openShopModal() {
        document.getElementById('shop-money-val').innerText = `₹${this.playerState.money}`;
        document.getElementById('screen-shop').classList.remove('hidden');
    }

    handleBuy(itemId) {
        const res = this.shop.buyItem(itemId);
        alert(res.message);
        document.getElementById('shop-money-val').innerText = `₹${this.playerState.money}`;
        this.updateHUD();

        if (res.success && itemId !== 'phone') {
            this.vehicleManager.mountVehicle(itemId);
            document.getElementById('txt-vehicle-name').innerText = ` riding ${itemId.toUpperCase()}`;
            document.getElementById('vehicle-hud').classList.remove('hidden');
            document.getElementById('screen-shop').classList.add('hidden');
        }
    }

    handleInteraction() {
        // Distance check for Cow Milking
        const distToCows = Math.hypot(this.controls.position.x - (-45), this.controls.position.z - (-30));
        if (distToCows < 15) {
            const msg = this.playerState.milkCow();
            alert(msg);
            this.updateHUD();
            return;
        }

        // Distance check for River Water drinking
        if (this.controls.position.x < -70) {
            this.playerState.drinkWater(50);
            alert("💧 You drank fresh clear water from the village river! (+50 Water, +10 Health)");
            this.updateHUD();
            return;
        }
    }

    updateHUD() {
        // Real-Time Up/Down Need Bars
        document.getElementById('bar-water').style.width = `${this.playerState.water}%`;
        document.getElementById('txt-water').innerText = `${Math.round(this.playerState.water)}%`;

        document.getElementById('bar-hunger').style.width = `${this.playerState.hunger}%`;
        document.getElementById('txt-hunger').innerText = `${Math.round(this.playerState.hunger)}%`;

        document.getElementById('bar-health').style.width = `${this.playerState.health}%`;
        document.getElementById('txt-health').innerText = `${Math.round(this.playerState.health)}%`;

        document.getElementById('bar-energy').style.width = `${this.playerState.energy}%`;
        document.getElementById('txt-energy').innerText = `${Math.round(this.playerState.energy)}%`;

        // Update Time, Money & Milk Cans
        const hrs = Math.floor(this.playerState.timeOfDay);
        const mins = Math.floor((this.playerState.timeOfDay % 1) * 60);
        const padHrs = hrs.toString().padStart(2, '0');
        const padMins = mins.toString().padStart(2, '0');
        const isNight = hrs < 6 || hrs >= 19;
        
        document.getElementById('txt-time').innerText = `DAY ${this.playerState.dayCount} - ${padHrs}:${padMins} ${isNight ? '🌙' : '☀️'}`;
        document.getElementById('txt-stage').innerText = `${this.playerState.lifeStage.toUpperCase()}`;
        
        // Education Progress string
        if (this.playerState.dayCount <= 10) {
            document.getElementById('txt-education-progress').innerText = `🎒 School: Day ${this.playerState.dayCount}/10 | College: Locked`;
        } else if (this.playerState.dayCount <= 20) {
            document.getElementById('txt-education-progress').innerText = `🎓 College: Day ${this.playerState.collegeDaysDone}/10 | Degree: Pending`;
        } else {
            document.getElementById('txt-education-progress').innerText = `📜 DEGREE EARNED: ${this.playerState.degreeName}`;
        }

        document.getElementById('txt-money').innerText = `₹${this.playerState.money}`;
        document.getElementById('txt-milk-cans').innerText = `${this.playerState.milkCans} Cans`;
    }

    animate(now) {
        if (!this.isRunning) return;

        requestAnimationFrame((t) => this.animate(t));

        const deltaTime = Math.min((now - this.lastTime) / 1000, 0.1);
        this.lastTime = now;

        // Update Physics & Controls
        this.controls.update(deltaTime);

        // Update Player State & Day-Night
        this.playerState.updateTime(deltaTime);
        this.renderer.updateDayNightCycle(this.playerState.timeOfDay / 24.0);

        // Check Proximity to River or Cows for interactive prompt
        const distToCows = Math.hypot(this.controls.position.x - (-45), this.controls.position.z - (-30));
        const prompt = document.getElementById('interaction-prompt');
        const promptTxt = document.getElementById('prompt-text');

        if (distToCows < 15) {
            prompt.classList.remove('hidden');
            promptTxt.innerText = "🐄 Press [E] or Tap MILK COW to collect milk!";
        } else if (this.controls.position.x < -70) {
            prompt.classList.remove('hidden');
            promptTxt.innerText = "💧 Press [E] or Tap ACTION to drink River Water!";
        } else {
            prompt.classList.add('hidden');
        }

        // Update HUD
        this.updateHUD();

        // Render Scene
        this.renderer.render();
    }
}

// Global Launch
window.addEventListener('load', () => {
    window.gameInstance = new VillageGame();
});
