// Three.js Renderer, Camera, Lighting & Day/Night Sky Manager
class VillageRenderer {
    constructor() {
        this.canvas = document.getElementById('three-canvas');
        this.scene = new THREE.Scene();
        
        // Camera
        this.camera = new THREE.PerspectiveCamera(
            60, 
            window.innerWidth / window.innerHeight, 
            0.1, 
            1000
        );
        this.camera.position.set(0, 5, 10);

        // WebGL Renderer
        this.renderer = new THREE.WebGLRenderer({
            canvas: this.canvas,
            antialias: true,
            alpha: false
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

        // Ambient & Sun Lighting
        this.ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(this.ambientLight);

        this.sunLight = new THREE.DirectionalLight(0xfffaed, 1.2);
        this.sunLight.position.set(50, 80, 50);
        this.sunLight.castShadow = true;
        this.sunLight.shadow.mapSize.width = 2048;
        this.sunLight.shadow.mapSize.height = 2048;
        this.sunLight.shadow.camera.near = 0.5;
        this.sunLight.shadow.camera.far = 300;
        const d = 100;
        this.sunLight.shadow.camera.left = -d;
        this.sunLight.shadow.camera.right = d;
        this.sunLight.shadow.camera.top = d;
        this.sunLight.shadow.camera.bottom = -d;
        this.scene.add(this.sunLight);

        // Sky & Fog
        this.skyColorDay = new THREE.Color(0x78c6fb);
        this.skyColorNight = new THREE.Color(0x050a18);
        this.scene.background = this.skyColorDay.clone();
        this.scene.fog = new THREE.FogExp2(0x78c6fb, 0.005);

        // Resize Listener
        window.addEventListener('resize', () => this.onResize());
    }

    onResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    updateDayNightCycle(timeNormalized) {
        // timeNormalized: 0.0 = 6 AM, 0.5 = 6 PM, 1.0 = 6 AM
        const sunAngle = timeNormalized * Math.PI * 2 - Math.PI / 2;
        const sunX = Math.cos(sunAngle) * 120;
        const sunY = Math.sin(sunAngle) * 120;
        
        this.sunLight.position.set(sunX, Math.max(sunY, -20), 50);

        if (sunY > 0) {
            // Day Time
            const dayFactor = Math.min(sunY / 40, 1);
            this.scene.background.lerpColors(this.skyColorNight, this.skyColorDay, dayFactor);
            this.scene.fog.color.copy(this.scene.background);
            this.sunLight.intensity = 0.3 + dayFactor * 0.9;
            this.ambientLight.intensity = 0.2 + dayFactor * 0.4;
        } else {
            // Night Time
            this.scene.background.copy(this.skyColorNight);
            this.scene.fog.color.copy(this.skyColorNight);
            this.sunLight.intensity = 0.1;
            this.ambientLight.intensity = 0.2;
        }
    }

    render() {
        this.renderer.render(this.scene, this.camera);
    }
}
