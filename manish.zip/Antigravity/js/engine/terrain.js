// 3D Minecraft / Low-Poly Indian Village Generator
class VillageTerrain {
    constructor(scene) {
        this.scene = scene;
        this.interactiveObjects = [];
        this.houses = [];
        this.cows = [];
        this.cryingBaby = null;

        this.buildWorld();
    }

    buildWorld() {
        // Ground Plane (Green Grass)
        const groundGeo = new THREE.PlaneGeometry(500, 500, 32, 32);
        const groundMat = new THREE.MeshStandardMaterial({
            color: 0x4baa32,
            roughness: 0.9,
            metalness: 0.1
        });
        const ground = new THREE.Mesh(groundGeo, groundMat);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        this.scene.add(ground);

        // Dirt Main Village Road (2 KM to School)
        const roadGeo = new THREE.PlaneGeometry(12, 450);
        const roadMat = new THREE.MeshStandardMaterial({ color: 0xc2a064, roughness: 0.95 });
        const road = new THREE.Mesh(roadGeo, roadMat);
        road.rotation.x = -Math.PI / 2;
        road.position.set(0, 0.05, 0);
        road.receiveShadow = true;
        this.scene.add(road);

        // River (Blue Water)
        const riverGeo = new THREE.PlaneGeometry(40, 500);
        const riverMat = new THREE.MeshStandardMaterial({
            color: 0x0099ff,
            roughness: 0.1,
            metalness: 0.8,
            transparent: true,
            opacity: 0.85
        });
        const river = new THREE.Mesh(riverGeo, riverMat);
        river.rotation.x = -Math.PI / 2;
        river.position.set(-90, 0.02, 0);
        this.scene.add(river);

        // River Bridge
        const bridgeGeo = new THREE.BoxGeometry(45, 1.5, 12);
        const bridgeMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b });
        const bridge = new THREE.Mesh(bridgeGeo, bridgeMat);
        bridge.position.set(-90, 0.8, 0);
        bridge.castShadow = true;
        this.scene.add(bridge);

        // Build 20 Traditional Village Houses
        for (let i = 0; i < 20; i++) {
            const isPlayerHome = (i === 0);
            const side = (i % 2 === 0) ? 1 : -1;
            const row = Math.floor(i / 2);
            const x = side * (25 + Math.random() * 8);
            const z = -120 + row * 22;

            this.createVillageHouse(x, z, isPlayerHome, i + 1);
        }

        // Build School & College Buildings at end of road (Z = 180)
        this.createSchoolBuilding(0, 190);
        this.createCollegeBuilding(-70, 190);

        // Build Farm Fields (Wheat & Mustard)
        this.createFarmField(60, -50, 0xebc034); // Yellow Mustard
        this.createFarmField(60, 20, 0x6e9e30);  // Green Wheat

        // Add Trees around Village & River
        for (let i = 0; i < 60; i++) {
            const tx = (Math.random() - 0.5) * 380;
            const tz = (Math.random() - 0.5) * 380;
            if (Math.abs(tx) > 10 || Math.abs(tz - 190) > 40) {
                this.createTree(tx, tz);
            }
        }

        // Add Cows in Pasture
        for (let i = 0; i < 6; i++) {
            this.createCow(-45 + i * 8, -30 + (i % 2) * 6);
        }

        // Add Evening Dayro Bonfire Spot
        this.createDayroSpot(20, -10);

        // Add Cricket Pitch
        this.createCricketPitch(-40, 50);

        // Add Mountains around Map edges
        this.createMountainChain();
    }

    createVillageHouse(x, z, isPlayerHome, houseNo) {
        const group = new THREE.Group();

        // Main Wall (Clay/Pukka style)
        const wallColor = isPlayerHome ? 0xfffae6 : (0xd9c5a0 + Math.floor(Math.random() * 0x111111));
        const wallGeo = new THREE.BoxGeometry(10, 6, 8);
        const wallMat = new THREE.MeshStandardMaterial({ color: wallColor, roughness: 0.8 });
        const wall = new THREE.Mesh(wallGeo, wallMat);
        wall.position.y = 3;
        wall.castShadow = true;
        wall.receiveShadow = true;
        group.add(wall);

        // Roof (Clay Tiles / Desi Naliya Red-Orange Roof)
        const roofGeo = new THREE.ConeGeometry(8, 4, 4);
        const roofMat = new THREE.MeshStandardMaterial({ color: 0xc84b23, roughness: 0.6 });
        const roof = new THREE.Mesh(roofGeo, roofMat);
        roof.position.y = 7;
        roof.rotation.y = Math.PI / 4;
        roof.castShadow = true;
        group.add(roof);

        // Wooden Door
        const doorGeo = new THREE.BoxGeometry(2, 4, 0.3);
        const doorMat = new THREE.MeshStandardMaterial({ color: 0x5c3a21 });
        const door = new THREE.Mesh(doorGeo, doorMat);
        door.position.set(0, 2, 4.1);
        group.add(door);

        group.position.set(x, 0, z);
        this.scene.add(group);

        if (isPlayerHome) {
            // Label player home
            group.name = "PlayerHome";
        }
        this.houses.push(group);
    }

    createSchoolBuilding(x, z) {
        const group = new THREE.Group();
        // Main School Block
        const mainGeo = new THREE.BoxGeometry(30, 10, 16);
        const mainMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.5 });
        const main = new THREE.Mesh(mainGeo, mainMat);
        main.position.y = 5;
        main.castShadow = true;
        group.add(main);

        // School Roof
        const roofGeo = new THREE.BoxGeometry(32, 2, 18);
        const roofMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a });
        const roof = new THREE.Mesh(roofGeo, roofMat);
        roof.position.y = 11;
        group.add(roof);

        group.position.set(x, 0, z);
        this.scene.add(group);
    }

    createCollegeBuilding(x, z) {
        const group = new THREE.Group();
        const mainGeo = new THREE.BoxGeometry(40, 14, 20);
        const mainMat = new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.4 });
        const main = new THREE.Mesh(mainGeo, mainMat);
        main.position.y = 7;
        main.castShadow = true;
        group.add(main);

        group.position.set(x, 0, z);
        this.scene.add(group);
    }

    createFarmField(x, z, cropColor) {
        const fieldGeo = new THREE.PlaneGeometry(50, 60);
        const fieldMat = new THREE.MeshStandardMaterial({ color: cropColor, roughness: 0.9 });
        const field = new THREE.Mesh(fieldGeo, fieldMat);
        field.rotation.x = -Math.PI / 2;
        field.position.set(x, 0.08, z);
        this.scene.add(field);
    }

    createTree(x, z) {
        const group = new THREE.Group();
        // Trunk
        const trunkGeo = new THREE.CylinderGeometry(0.5, 0.8, 5, 6);
        const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4033 });
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.y = 2.5;
        trunk.castShadow = true;
        group.add(trunk);

        // Foliage (Minecraft Low-poly blocky leaves)
        const foliageGeo = new THREE.DodecahedronGeometry(3.5, 0);
        const foliageMat = new THREE.MeshStandardMaterial({ color: 0x228b22, roughness: 0.8 });
        const foliage = new THREE.Mesh(foliageGeo, foliageMat);
        foliage.position.y = 6;
        foliage.castShadow = true;
        group.add(foliage);

        group.position.set(x, 0, z);
        this.scene.add(group);
    }

    createCow(x, z) {
        const group = new THREE.Group();
        // Body
        const bodyGeo = new THREE.BoxGeometry(2.5, 1.8, 3.5);
        const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf5f5f5, roughness: 0.8 });
        const body = new THREE.Mesh(bodyGeo, bodyMat);
        body.position.y = 1.8;
        body.castShadow = true;
        group.add(body);

        // Head
        const headGeo = new THREE.BoxGeometry(1.2, 1.2, 1.5);
        const head = new THREE.Mesh(headGeo, bodyMat);
        head.position.set(0, 2.4, 2);
        group.add(head);

        group.position.set(x, 0, z);
        this.scene.add(group);
        this.cows.push(group);
    }

    createDayroSpot(x, z) {
        const group = new THREE.Group();
        // Fire pit stones
        const pitGeo = new THREE.CylinderGeometry(2, 2, 0.4, 8);
        const pitMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
        const pit = new THREE.Mesh(pitGeo, pitMat);
        pit.position.y = 0.2;
        group.add(pit);

        // Fire Flame light
        const fireLight = new THREE.PointLight(0xff7700, 2, 25);
        fireLight.position.set(0, 1.5, 0);
        group.add(fireLight);

        group.position.set(x, 0, z);
        this.scene.add(group);
    }

    createCricketPitch(x, z) {
        const pitchGeo = new THREE.PlaneGeometry(6, 22);
        const pitchMat = new THREE.MeshStandardMaterial({ color: 0xd2b48c, roughness: 0.95 });
        const pitch = new THREE.Mesh(pitchGeo, pitchMat);
        pitch.rotation.x = -Math.PI / 2;
        pitch.position.set(x, 0.06, z);
        this.scene.add(pitch);
    }

    createMountainChain() {
        for (let i = 0; i < 20; i++) {
            const angle = (i / 20) * Math.PI * 2;
            const dist = 220 + Math.random() * 20;
            const x = Math.cos(angle) * dist;
            const z = Math.sin(angle) * dist;

            const mtnGeo = new THREE.ConeGeometry(25 + Math.random() * 15, 45 + Math.random() * 25, 5);
            const mtnMat = new THREE.MeshStandardMaterial({ color: 0x4a5d4e, roughness: 0.95 });
            const mtn = new THREE.Mesh(mtnGeo, mtnMat);
            mtn.position.set(x, 20, z);
            this.scene.add(mtn);
        }
    }
}
