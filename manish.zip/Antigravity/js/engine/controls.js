// Smooth Character Physics, Touch Joystick & Vehicle Driving Controls
class PlayerControls {
    constructor(camera, domElement) {
        this.camera = camera;
        this.domElement = domElement;

        // Player Position & Movement Physics
        this.position = new THREE.Vector3(0, 0, -110); // Start in front of Player Home
        this.velocity = new THREE.Vector3();
        this.rotationY = 0;
        this.rotationX = 0;

        // Flags & Stats
        this.isGrounded = true;
        this.isSprinting = false;
        this.moveForward = false;
        this.moveBackward = false;
        this.moveLeft = false;
        this.moveRight = false;
        this.jumpRequested = false;

        // Touch Joystick Vector (-1 to 1)
        this.touchMove = { x: 0, y: 0 };

        // Mount / Vehicle state
        this.currentVehicle = null; // null | 'bicycle' | 'motorbike' | 'car' | 'bullock'

        this.initEventListeners();
        this.initTouchControls();
    }

    initEventListeners() {
        // Keyboard controls
        window.addEventListener('keydown', (e) => {
            switch(e.code) {
                case 'KeyW': case 'ArrowUp': this.moveForward = true; break;
                case 'KeyS': case 'ArrowDown': this.moveBackward = true; break;
                case 'KeyA': case 'ArrowLeft': this.moveLeft = true; break;
                case 'KeyD': case 'ArrowRight': this.moveRight = true; break;
                case 'Space': 
                    if (this.isGrounded) this.jumpRequested = true; 
                    e.preventDefault();
                    break;
                case 'ShiftLeft': case 'ShiftRight': this.isSprinting = true; break;
                case 'KeyE':
                    // Trigger interaction / Dismount
                    if (window.gameInstance) window.gameInstance.handleInteraction();
                    break;
            }
        });

        window.addEventListener('keyup', (e) => {
            switch(e.code) {
                case 'KeyW': case 'ArrowUp': this.moveForward = false; break;
                case 'KeyS': case 'ArrowDown': this.moveBackward = false; break;
                case 'KeyA': case 'ArrowLeft': this.moveLeft = false; break;
                case 'KeyD': case 'ArrowRight': this.moveRight = false; break;
                case 'ShiftLeft': case 'ShiftRight': this.isSprinting = false; break;
            }
        });

        // Pointer Lock & Touch Look Around
        let isDragging = false;
        let prevTouchX = 0, prevTouchY = 0;

        window.addEventListener('pointerdown', (e) => {
            if (e.target.tagName !== 'BUTTON' && !e.target.closest('#hud') && !e.target.closest('.screen-overlay')) {
                isDragging = true;
                prevTouchX = e.clientX;
                prevTouchY = e.clientY;
            }
        });

        window.addEventListener('pointermove', (e) => {
            if (isDragging) {
                const deltaX = e.clientX - prevTouchX;
                const deltaY = e.clientY - prevTouchY;
                prevTouchX = e.clientX;
                prevTouchY = e.clientY;

                this.rotationY -= deltaX * 0.004;
                this.rotationX -= deltaY * 0.003;
                this.rotationX = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, this.rotationX));
            }
        });

        window.addEventListener('pointerup', () => { isDragging = false; });
    }

    initTouchControls() {
        const base = document.getElementById('joystick-base');
        const thumb = document.getElementById('joystick-thumb');
        if (!base || !thumb) return;

        let active = false;
        let startX = 0, startY = 0;

        const onStart = (e) => {
            active = true;
            const touch = e.touches ? e.touches[0] : e;
            const rect = base.getBoundingClientRect();
            startX = rect.left + rect.width / 2;
            startY = rect.top + rect.height / 2;
        };

        const onMove = (e) => {
            if (!active) return;
            const touch = e.touches ? e.touches[0] : e;
            let dx = touch.clientX - startX;
            let dy = touch.clientY - startY;

            const dist = Math.hypot(dx, dy);
            const maxDist = 45;

            if (dist > maxDist) {
                dx = (dx / dist) * maxDist;
                dy = (dy / dist) * maxDist;
            }

            thumb.style.transform = `translate(${dx}px, ${dy}px)`;
            this.touchMove.x = dx / maxDist;
            this.touchMove.y = dy / maxDist;
        };

        const onEnd = () => {
            active = false;
            thumb.style.transform = `translate(0px, 0px)`;
            this.touchMove.x = 0;
            this.touchMove.y = 0;
        };

        base.addEventListener('touchstart', onStart);
        window.addEventListener('touchmove', onMove);
        window.addEventListener('touchend', onEnd);

        // Mobile Buttons
        const btnJump = document.getElementById('btn-touch-jump');
        if (btnJump) {
            btnJump.addEventListener('touchstart', (e) => {
                e.preventDefault();
                if (this.isGrounded) this.jumpRequested = true;
            });
        }

        const btnRun = document.getElementById('btn-touch-run');
        if (btnRun) {
            btnRun.addEventListener('touchstart', (e) => {
                e.preventDefault();
                this.isSprinting = !this.isSprinting;
            });
        }
    }

    update(deltaTime) {
        // Calculate Movement Vector
        let inputZ = 0, inputX = 0;

        if (this.moveForward) inputZ -= 1;
        if (this.moveBackward) inputZ += 1;
        if (this.moveLeft) inputX -= 1;
        if (this.moveRight) inputX += 1;

        if (Math.abs(this.touchMove.y) > 0.1) inputZ = this.touchMove.y;
        if (Math.abs(this.touchMove.x) > 0.1) inputX = this.touchMove.x;

        // Determine Speed multiplier (Walking vs Running vs Vehicle)
        let speed = 8.0;
        if (this.isSprinting) speed *= 1.8;

        if (this.currentVehicle === 'bicycle') speed = 18.0;
        else if (this.currentVehicle === 'motorbike') speed = 32.0;
        else if (this.currentVehicle === 'car') speed = 45.0;

        // Apply Rotation relative to Camera View
        const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationY);
        const right = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationY);

        const moveDir = new THREE.Vector3()
            .addScaledVector(forward, -inputZ)
            .addScaledVector(right, inputX);

        if (moveDir.lengthSq() > 0.01) {
            moveDir.normalize();
            this.position.addScaledVector(moveDir, speed * deltaTime);

            // Play step sound
            if (this.isGrounded && Math.random() < 0.1) {
                if (this.currentVehicle === 'bicycle') audio.playBicycleBell();
                else if (this.currentVehicle === 'motorbike') audio.playMotorbikeEngine();
                else audio.playStep();
            }
        }

        // Jump & Gravity Physics
        if (this.jumpRequested && this.isGrounded && !this.currentVehicle) {
            this.velocity.y = 7.5;
            this.isGrounded = false;
            this.jumpRequested = false;
        }

        // Apply Gravity
        this.velocity.y -= 22.0 * deltaTime;
        this.position.y += this.velocity.y * deltaTime;

        // Ground Collision (Y = 0)
        let groundLevel = 0.5;
        if (this.currentVehicle) groundLevel = 1.2;

        if (this.position.y <= groundLevel) {
            this.position.y = groundLevel;
            this.velocity.y = 0;
            this.isGrounded = true;
        }

        // Clamp Map Boundaries
        this.position.x = Math.max(-230, Math.min(230, this.position.x));
        this.position.z = Math.max(-230, Math.min(230, this.position.z));

        // Update Camera Position & Target (Third-person view)
        const camOffset = new THREE.Vector3(0, 3.2, 7.5).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationY);
        this.camera.position.copy(this.position).add(camOffset);

        const lookTarget = this.position.clone().add(new THREE.Vector3(0, 2.0, 0));
        lookTarget.add(new THREE.Vector3(0, Math.sin(this.rotationX) * 4, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationY));
        this.camera.lookAt(lookTarget);
    }
}
